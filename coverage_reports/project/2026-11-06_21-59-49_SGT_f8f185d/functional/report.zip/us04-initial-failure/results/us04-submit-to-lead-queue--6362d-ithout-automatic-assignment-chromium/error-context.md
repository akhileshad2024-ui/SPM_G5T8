# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: us04-submit-to-lead-queue.spec.ts >> [US04-TC03][US04-AC4] UI submission reaches the Lead queue without automatic assignment
- Location: tests/functional/us04-submit-to-lead-queue.spec.ts:40:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('region', { name: 'Unassigned requests', exact: true }).locator('[aria-label^="Unassigned request:"]').filter({ hasText: /\bEVT-1\b/ })
Expected: 1
Received: 0
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" getByRole('region', { name: 'Unassigned requests', exact: true }).locator('[aria-label^="Unassigned request:"]').filter({ hasText: /\bEVT-1\b/ }) with timeout 10000ms
  - waiting for getByRole('region', { name: 'Unassigned requests', exact: true }).locator('[aria-label^="Unassigned request:"]').filter({ hasText: /\bEVT-1\b/ })
    24 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - button "Open Next.js Dev Tools" [ref=f1e7] [cursor=pointer]
  - alert [ref=f1e11]
  - generic [ref=f1e12]:
    - generic [ref=f1e13]:
      - generic [ref=f1e14]:
        - generic [ref=f1e15]: ConnectSphere
        - generic [ref=f1e16]: Event operations
      - generic [ref=f1e17]:
        - generic [ref=f1e18]: Event Coordinator Lead
        - link "Assignments" [ref=f1e19] [cursor=pointer]:
          - /url: /assignments
      - generic [ref=f1e21]:
        - generic [ref=f1e22]:
          - generic [ref=f1e23]: JL
          - generic [ref=f1e24]:
            - generic [ref=f1e25]: Jordan Lee
            - generic [ref=f1e26]: jordan.lee@connectsphere.edu
        - generic [ref=f1e27]:
          - button "Change password" [ref=f1e28] [cursor=pointer]
          - button "Sign out" [ref=f1e29] [cursor=pointer]
    - generic [ref=f1e30]:
      - generic [ref=f1e31]:
        - generic [ref=f1e32]:
          - generic [ref=f1e33]: Assignments
          - generic [ref=f1e34]: 1 request waiting for a coordinator
        - button "Notifications" [ref=f1e36] [cursor=pointer]
      - generic [ref=f1e39]:
        - region "Unassigned requests" [ref=f1e40]:
          - generic [ref=f1e41]: Unassigned requests (1)
          - 'generic "Unassigned request: US04 Lead Queue Handover Test" [ref=f1e42]':
            - generic [ref=f1e43]:
              - generic [ref=f1e44]:
                - generic [ref=f1e45]:
                  - generic [ref=f1e46]: US04 Lead Queue Handover Test
                  - generic [ref=f1e47]: Submitted
                - generic [ref=f1e48]: EVT-1 · Maya Rahman · 25 Oct 2026, 18:00–21:00 · 85 expected
                - generic [ref=f1e49]: Testing submission to the Lead queue
              - generic [ref=f1e50]:
                - combobox "Coordinator to assign" [ref=f1e51]:
                  - option "Choose a coordinator…" [selected]
                  - option "Marcus Lee"
                  - option "Priya Tan"
                - button "Assign" [disabled] [ref=f1e52]
            - button "Details" [ref=f1e55] [cursor=pointer]
        - region "Coordinators" [ref=f1e56]:
          - generic [ref=f1e58]:
            - 'generic "Coordinator: Marcus Lee" [ref=f1e59]':
              - generic [ref=f1e60]:
                - strong [ref=f1e61]: Marcus Lee
                - generic [ref=f1e62]: 0 active
              - list [ref=f1e63]:
                - listitem [ref=f1e64]: No active events.
            - 'generic "Coordinator: Priya Tan" [ref=f1e65]':
              - generic [ref=f1e66]:
                - strong [ref=f1e67]: Priya Tan
                - generic [ref=f1e68]: 0 active
              - list [ref=f1e69]:
                - listitem [ref=f1e70]: No active events.
```

# Test source

```ts
  6   | const NAME = "US04 Lead Queue Handover Test";
  7   | const PURPOSE = "Testing submission to the Lead queue";
  8   | test.use({ timezoneId: "Asia/Singapore" });
  9   | 
  10  | // Credentials differ by environment; business actions never bypass the UI.
  11  | async function login(page: Page, person: typeof MAYA, landing: RegExp) {
  12  |   const password = shared
  13  |     ? process.env[person.email === MAYA.email ? "TC_MAYA_PASSWORD" : "TC_JORDAN_PASSWORD"]
  14  |     : PASSWORD;
  15  |   if (!password) throw new Error("Supply the authorised TC password before running.");
  16  |   await page.goto("/login");
  17  |   await page.getByPlaceholder("you@connectsphere.edu").fill(person.email);
  18  |   await page.locator('input[type="password"]').fill(password);
  19  |   const loaded = page.waitForResponse(r => r.url().endsWith("/api/events") && r.request().method() === "GET");
  20  |   await action(page, "Sign in").click();
  21  |   await expect(page).toHaveURL(landing);
  22  |   const response = await loaded;
  23  |   expect(response.ok(), "The UI must load saved events before checking them.").toBeTruthy();
  24  |   if (person.email === MAYA.email) {
  25  |     await expect(page.getByRole("link", { name: "View", exact: true })).toHaveCount((await response.json()).length);
  26  |   }
  27  | }
  28  | 
  29  | async function logout(page: Page) {
  30  |   const done = page.waitForResponse(r => r.url().includes("/api/auth/logout") && r.request().method() === "POST");
  31  |   await action(page, "Sign out").click();
  32  |   expect((await done).status()).toBe(204);
  33  |   await expect(page).toHaveURL(/\/login/);
  34  | }
  35  | 
  36  | function field(page: Page, label: string) {
  37  |   return page.locator("div.field").filter({ has: page.locator("label", { hasText: new RegExp(`^${label}$`) }) });
  38  | }
  39  | 
  40  | test("[US04-TC03][US04-AC4] UI submission reaches the Lead queue without automatic assignment", async ({ page }, info) => {
  41  |   test.setTimeout(120_000);
  42  |   const date = singaporeTestDate(new Date()); // Capture once; no expiring literal date.
  43  |   await info.attach("test-date", { body: `EVENT_DATE=${date.iso}; Asia/Singapore`, contentType: "text/plain" });
  44  | 
  45  |   // TC steps 1–5: real login and a fully loaded baseline, not a fixed count/ID.
  46  |   await login(page, MAYA, /\/my-events$/);
  47  |   await page.getByRole("link", { name: /^My events$/i }).click();
  48  |   const views = page.getByRole("link", { name: "View", exact: true });
  49  |   const before = await views.evaluateAll(links => links.map(link => link.getAttribute("href")));
  50  |   await action(page, "New event request").click();
  51  | 
  52  |   // Steps 6–10: the exact English TC inputs, including explicit selections.
  53  |   await page.getByPlaceholder("Alumni Homecoming Dinner").fill(NAME);
  54  |   await page.getByPlaceholder("What is this event for, and who is it for?").fill(PURPOSE);
  55  |   await field(page, "Expected attendance").locator("input").fill("85");
  56  |   await field(page, "Event type").locator("select").selectOption({ label: "Conference" });
  57  |   await field(page, "Proposed date").locator("input").fill(date.iso);
  58  |   await field(page, "Start").locator("input").fill("18:00");
  59  |   await field(page, "End").locator("input").fill("21:00");
  60  |   await action(page, "Continue").click();
  61  |   await field(page, "Preferred venue location").locator("input").fill("");
  62  |   await field(page, "Required capacity").locator("input").fill("");
  63  |   await action(page, "Banquet").click();
  64  |   for (const [label, selected] of [["Facilities needed", "PA system"], ["Accessibility needs", "Wheelchair Access"]]) {
  65  |     const choices = field(page, label);
  66  |     for (const button of await choices.getByRole("button").all()) {
  67  |       const wanted = (await button.innerText()) === selected;
  68  |       const on = (await button.getAttribute("class"))?.includes("chipOn") ?? false;
  69  |       if (wanted !== on) await button.click();
  70  |     }
  71  |     await expect(choices.getByRole("button", { name: selected, exact: true })).toHaveClass(/chipOn/);
  72  |   }
  73  |   const quantities = page.locator('[class*="stepperValue"]');
  74  |   expect(await quantities.count()).toBeGreaterThan(0);
  75  |   for (const quantity of await quantities.all()) await expect(quantity).toHaveText("0");
  76  |   await expect(page.getByPlaceholder("Connections, setup, compatibility or power needs")).toHaveCount(0);
  77  |   await action(page, "Continue").click();
  78  |   await page.getByRole("checkbox", { name: /Enable attendee registration/ }).uncheck();
  79  | 
  80  |   // Steps 11–12: submit ONCE; find the new ID by baseline difference.
  81  |   expect(singaporeTestDate(new Date()).iso, "Restart if midnight crossed before submission.").toBe(date.iso);
  82  |   await action(page, "Submit for review").click();
  83  |   await expect(page).toHaveURL(/\/my-events$/);
  84  |   await expect(views).toHaveCount(before.length + 1);
  85  |   const added = (await views.evaluateAll(links => links.map(link => link.getAttribute("href"))))
  86  |     .filter(href => !before.includes(href));
  87  |   expect(added).toHaveLength(1);
  88  |   const href = added[0]!;
  89  |   const id = href.split("/").pop()!;
  90  |   const row = page.locator('[class*="MyEventsTable"][class*="row"]').filter({ has: page.locator(`a[href="${href}"]`) });
  91  |   await expect(row).toContainText(NAME);
  92  |   await expect(row.getByText("85", { exact: true })).toBeVisible();
  93  |   await expect(row.locator(".pill")).toHaveText("Submitted");
  94  |   await expect(row.getByRole("button", { name: "Continue", exact: true })).toHaveCount(0);
  95  |   await expect(row.getByRole("button", { name: /Submit/ })).toHaveCount(0);
  96  |   const record = `EVENT_ID=${id}; EVENT_DATE=${date.iso}; Maya count ${before.length} -> ${before.length + 1}; environment=${shared ? "shared acceptance" : "isolated regression"}`;
  97  |   console.log(`US04-TC03 ${record}`);
  98  |   await info.attach("event-record", { body: record, contentType: "text/plain" });
  99  | 
  100 |   // Steps 13–20: Lead reads the SAME ID, including fresh page/session checks.
  101 |   await logout(page);
  102 |   await login(page, JORDAN, /\/assignments$/);
  103 |   const card = page.getByRole("region", { name: "Unassigned requests", exact: true })
  104 |     .locator('[aria-label^="Unassigned request:"]').filter({ hasText: new RegExp(`\\bEVT-${id}\\b`) });
  105 |   async function checkUnassigned() {
> 106 |     await expect(card).toHaveCount(1);
      |                        ^ Error: expect(locator).toHaveCount(expected) failed
  107 |     for (const value of [NAME, PURPOSE, MAYA.name, date.iso, "18:00–21:00", "85 expected"]) await expect(card).toContainText(value);
  108 |     await expect(card.locator(".pill")).toHaveText("Submitted");
  109 |     await expect(card.getByLabel("Coordinator to assign")).toHaveValue("");
  110 |     await expect(card.getByRole("button", { name: "Assign", exact: true })).toBeDisabled();
  111 |     await card.getByRole("button", { name: "Details", exact: true }).click();
  112 |     await expect(card.getByRole("region", { name: "People", exact: true })).toContainText("Not yet assigned");
  113 |   }
  114 |   await checkUnassigned();
  115 |   await page.reload();
  116 |   await checkUnassigned();
  117 |   await logout(page);
  118 |   await login(page, JORDAN, /\/assignments$/);
  119 |   await checkUnassigned();
  120 |   await logout(page); // Leave data intact; never assign/delete/reset for test cleanup.
  121 | });
  122 | 
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: us15-view-event-information.spec.ts >> US15 - View Event Information >> [TC-052] [US15-AC1] the coordinator can view the information of an event assigned to them
- Location: tests/functional/us15-view-event-information.spec.ts:77:7

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 8
+ Received  + 1

- Array [
-   "Event",
-   "People",
-   "Venue",
-   "Equipment",
-   "Registration",
-   "Review",
- ]
+ Array []
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]
  - alert [ref=e11]
  - generic [ref=e12]:
    - generic [ref=e13]:
      - generic [ref=e14]:
        - generic [ref=e15]: ConnectSphere
        - generic [ref=e16]: Event operations
      - generic [ref=e17]:
        - generic [ref=e18]: Event Coordinator
        - link "Review queue 18" [ref=e19] [cursor=pointer]:
          - /url: /queue
          - generic [ref=e20]: Review queue
          - generic [ref=e21]: "18"
        - link "Pipeline" [ref=e22] [cursor=pointer]:
          - /url: /board
        - link "Venues" [ref=e24] [cursor=pointer]:
          - /url: /venues
        - link "Event registrations" [ref=e26] [cursor=pointer]:
          - /url: /registrations
      - generic [ref=e28]:
        - generic [ref=e29]:
          - generic [ref=e30]: PT
          - generic [ref=e31]:
            - generic [ref=e32]: Priya Tan
            - generic [ref=e33]: priya.tan@connectsphere.edu
        - generic [ref=e34]:
          - button "Change password" [ref=e35] [cursor=pointer]
          - button "Sign out" [ref=e36] [cursor=pointer]
    - generic [ref=e37]:
      - generic [ref=e38]:
        - generic [ref=e39]:
          - generic [ref=e40]: Review queue
          - generic [ref=e41]: 18 requests need a decision from you
        - button "Notifications" [ref=e43] [cursor=pointer]
      - generic [ref=e46]:
        - generic [ref=e47]:
          - generic [ref=e48]:
            - textbox "Search events, organisers or IDs" [ref=e49]: Annual Research Symposium info mvmgfoep
            - generic [ref=e50]:
              - button "Needs action" [ref=e51] [cursor=pointer]
              - button "Unassigned" [ref=e52] [cursor=pointer]
              - button "Mine" [ref=e53] [cursor=pointer]
              - button "All" [ref=e54] [cursor=pointer]
          - 'button "Annual Research Symposium info mvmgfoep Confirmed Maya Rahman · 180 pax · 27 Nov 2026 Coordinator: Priya Tan submitted" [ref=e56] [cursor=pointer]':
            - generic [ref=e57]:
              - generic [ref=e58]: Annual Research Symposium info mvmgfoep
              - generic [ref=e59]: Confirmed
            - generic [ref=e60]: Maya Rahman · 180 pax · 27 Nov 2026
            - generic [ref=e61]: "Coordinator: Priya Tan"
            - generic [ref=e62]: submitted
        - generic [ref=e63]:
          - generic [ref=e64]:
            - generic [ref=e65]:
              - generic [ref=e66]:
                - generic [ref=e67]: Annual Research Symposium info mvmgfoep
                - generic [ref=e68]: Confirmed
              - generic [ref=e69]: EVT-41 · Maya Rahman · 27 Nov 2026, 09:00–17:00 · 180 expected
              - time [ref=e71]: Last updated 24 Oct 2026, 21:48
            - button "Equipment pending with Technical Support" [ref=e73]
          - generic [ref=e74]:
            - button "Request" [ref=e75] [cursor=pointer]
            - button "Venue" [ref=e76] [cursor=pointer]
            - button "Equipment" [ref=e77] [cursor=pointer]
            - button "Registration" [ref=e78] [cursor=pointer]
            - button "Activity" [ref=e79] [cursor=pointer]
          - generic [ref=e81]:
            - generic [ref=e82]:
              - generic [ref=e83]:
                - region "Existing arrangements" [ref=e84]:
                  - heading "Existing arrangements" [level=3] [ref=e85]
                  - paragraph [ref=e86]: Review these alongside the proposal. Recording a decision does not change event details or arrangements.
                  - paragraph [ref=e87]: "Event: 27 Nov 2026, 09:00–17:00; expected attendance 180."
                  - list [ref=e88]:
                    - listitem [ref=e89]: "Symposium Hall info mvmgfoep: approved; 2026-11-27, 09:00–17:00; attendance 180; layout theatre."
                  - paragraph [ref=e90]: "Equipment: requested. Projector × 2"
                  - paragraph [ref=e91]: "Registration: 0 registered / capacity 200."
                  - paragraph [ref=e92]: Use Venue, Equipment and Registration tabs for the available arrangement details.
                - region "Change requests" [ref=e93]:
                  - heading "Change requests" [level=3] [ref=e94]
                  - paragraph [ref=e95]: No change requests recorded.
              - generic [ref=e96]:
                - generic [ref=e97]: Approved
                - generic [ref=e98]: Priya Tan · 24 Oct 2026, 21:48
                - generic [ref=e99]: Programme and venue confirmed.
              - generic [ref=e100]:
                - generic [ref=e101]: Purpose
                - generic [ref=e102]: Faculty and students present this year's research.
                - generic [ref=e104]:
                  - generic [ref=e105]:
                    - generic [ref=e106]: Event type
                    - generic [ref=e107]: conference
                  - generic [ref=e108]:
                    - generic [ref=e109]: Proposed date
                    - generic [ref=e110]: 27 Nov 2026
                  - generic [ref=e111]:
                    - generic [ref=e112]: Time
                    - generic [ref=e113]: 09:00 – 17:00
                  - generic [ref=e114]:
                    - generic [ref=e115]: Expected attendance
                    - generic [ref=e116]: "180"
                  - generic [ref=e117]:
                    - generic [ref=e118]: Venue requirements
                    - generic [ref=e119]: Central campus · capacity 200
                  - generic [ref=e120]:
                    - generic [ref=e121]: Required layout
                    - generic [ref=e122]: Theatre
                  - generic [ref=e123]:
                    - generic [ref=e124]: Facilities
                    - generic [ref=e125]: Projector, PA system
                  - generic [ref=e126]:
                    - generic [ref=e127]: Accessibility
                    - generic [ref=e128]: Wheelchair Access
                  - generic [ref=e129]:
                    - generic [ref=e130]: Equipment
                    - generic [ref=e131]: 2 × Projector (HDMI to lectern)
                  - generic [ref=e132]:
                    - generic [ref=e133]: Registration
                    - generic [ref=e134]: Enabled · cap 200 · closes 2026-11-20
                - generic [ref=e135]: Submitted 24 Oct 2026, 21:41
                - generic [ref=e137]:
                  - button "Hide details" [expanded] [active] [ref=e138] [cursor=pointer]
                  - generic [ref=e140]:
                    - time [ref=e142]: Last updated 24 Oct 2026, 21:48
                    - region "Event" [ref=e143]:
                      - generic [ref=e145]:
                        - generic [ref=e146]:
                          - term [ref=e147]: Status
                          - definition [ref=e148]: Confirmed
                        - generic [ref=e149]:
                          - term [ref=e150]: Event type
                          - definition [ref=e151]: Conference
                        - generic [ref=e152]:
                          - term [ref=e153]: Description
                          - definition [ref=e154]: Faculty and students present this year's research.
                        - generic [ref=e155]:
                          - term [ref=e156]: Date
                          - definition [ref=e157]: 27 Nov 2026
                        - generic [ref=e158]:
                          - term [ref=e159]: Time
                          - definition [ref=e160]: 09:00 – 17:00
                        - generic [ref=e161]:
                          - term [ref=e162]: Expected attendance
                          - definition [ref=e163]: "180"
                    - region "People" [ref=e164]:
                      - generic [ref=e166]:
                        - generic [ref=e167]:
                          - term [ref=e168]: Organiser
                          - definition [ref=e169]: Maya Rahman
                        - generic [ref=e170]:
                          - term [ref=e171]: Coordinator
                          - definition [ref=e172]: Priya Tan
                    - region "Venue" [ref=e173]:
                      - generic [ref=e175]:
                        - generic [ref=e176]:
                          - term [ref=e177]: Venue
                          - definition [ref=e178]: Symposium Hall info mvmgfoep
                        - generic [ref=e179]:
                          - term [ref=e180]: Booking
                          - definition [ref=e181]: Approved
                        - generic [ref=e182]:
                          - term [ref=e183]: Preferred location
                          - definition [ref=e184]: Central campus
                        - generic [ref=e185]:
                          - term [ref=e186]: Required capacity
                          - definition [ref=e187]: "200"
                        - generic [ref=e188]:
                          - term [ref=e189]: Layout
                          - definition [ref=e190]: Theatre
                        - generic [ref=e191]:
                          - term [ref=e192]: Facilities
                          - definition [ref=e193]: Projector, PA system
                        - generic [ref=e194]:
                          - term [ref=e195]: Accessibility
                          - definition [ref=e196]: Wheelchair Access
                    - region "Equipment" [ref=e197]:
                      - generic [ref=e199]:
                        - generic [ref=e200]:
                          - term [ref=e201]: Requested
                          - definition [ref=e202]: 2 × Projector (HDMI to lectern)
                        - generic [ref=e203]:
                          - term [ref=e204]: Equipment status
                          - definition [ref=e205]: Requested
                    - region "Registration" [ref=e206]:
                      - generic [ref=e208]:
                        - generic [ref=e209]:
                          - term [ref=e210]: Attendee registration
                          - definition [ref=e211]: Open
                        - generic [ref=e212]:
                          - term [ref=e213]: Capacity limit
                          - definition [ref=e214]: "200"
                        - generic [ref=e215]:
                          - term [ref=e216]: Closes
                          - definition [ref=e217]: 20 Nov 2026
                        - generic [ref=e218]:
                          - term [ref=e219]: Places taken
                          - definition [ref=e220]: 0 of 200
                        - generic [ref=e221]:
                          - term [ref=e222]: Withdraw by
                          - definition [ref=e223]: 13 Nov 2026
                    - region "Review" [ref=e224]:
                      - generic [ref=e226]:
                        - generic [ref=e227]:
                          - term [ref=e228]: Submitted
                          - definition [ref=e229]: 24 Oct 2026, 21:41
                        - generic [ref=e230]:
                          - term [ref=e231]: Decision
                          - definition [ref=e232]: "Approved: Programme and venue confirmed."
            - generic [ref=e233]:
              - generic [ref=e234]:
                - generic [ref=e235]: Coordinator
                - generic [ref=e236]: Priya Tan
              - generic [ref=e237]:
                - generic [ref=e238]: Readiness
                - generic [ref=e239]:
                  - generic [ref=e240]:
                    - generic [ref=e242]: Coordinator
                    - generic [ref=e243]: Assigned
                  - generic [ref=e244]:
                    - generic [ref=e246]: Venue
                    - generic [ref=e247]: Symposium Hall info mvmgfoep
                  - generic [ref=e248]:
                    - generic [ref=e250]: Equipment
                    - generic [ref=e251]: Requested
                  - generic [ref=e252]:
                    - generic [ref=e254]: Registration
                    - generic [ref=e255]: 0 / 200
    - generic [ref=e256]: Signed in as Priya Tan · Event Coordinator.
```

# Test source

```ts
  1   | import { expect, test, type Locator, type Page } from "@playwright/test";
  2   | import { MAYA, PRIYA, SAM, WEI, apiAs, createRequest, myEventsRow, openInQueue, signIn, toast, unique } from "./support/app";
  3   | import { DANIEL, observed } from "./support/venues";
  4   | import { scenarioNames, seedScenario, type Scenario } from "./support/scenario";
  5   | 
  6   | /**
  7   |  * US15 — View Event Information (functional).
  8   |  * "As an involved user, I want to view the information of an event so that I have the details
  9   |  * relevant to my role."
  10  |  *
  11  |  * Test cases: docs/testing/US15_View_Event_Information_Test_Cases.xlsx (TC-051 to TC-062), run here in
  12  |  * a real browser against the functional-test database, with the same test-data events as US13
  13  |  * (tests/functional/support/seed_events.py).
  14  |  */
  15  | let s: Scenario;
  16  | let names: ReturnType<typeof scenarioNames>;
  17  | test.beforeAll(() => {
  18  |   s = seedScenario(unique("info"));
  19  |   names = scenarioNames(s);
  20  | });
  21  | 
  22  | const ALL_SECTIONS = ["Event", "People", "Venue", "Equipment", "Registration", "Review"];
  23  | 
  24  | // Fields each role gets, as backend/event_fields.py defines them.
  25  | const BASICS = ["id", "status", "name", "purpose", "eventType", "date", "start", "end", "organiserId", "organiser", "updatedAt"];
  26  | const FIELDS: Record<string, string[]> = {
  27  |   organiser: [...BASICS, "coordinatorId", "coordinator", "pax", "venueLocation", "venueCapacity", "layout", "facilities", "access",
  28  |     "venue", "venueName", "bookingState", "equip", "equipState", "reg", "regCap", "regClose", "registered", "withdrawalClose",
  29  |     "clarification", "decision", "submittedAt", "createdAt", "draftForm"],
  30  |   tech: [...BASICS, "coordinatorId", "coordinator", "pax", "venueName", "equip", "equipState"],
  31  |   attendee: [...BASICS, "access", "venueName", "reg", "regCap", "regClose", "registered", "withdrawalClose"],
  32  | };
  33  | FIELDS.coordinator = FIELDS.organiser.filter((f) => f !== "draftForm");
  34  | FIELDS.venue = [...BASICS, "coordinatorId", "coordinator", "pax", "venueLocation", "venueCapacity", "layout", "facilities", "access",
  35  |   "venue", "venueName", "bookingState"];
  36  | 
  37  | /** Check only US15 details, not adjacent features such as US33 change requests. */
  38  | const sectionTitles = (scope: Locator) => scope.getByTestId("event-details").locator("section[aria-label]").evaluateAll((els) => els.map((e) => e.getAttribute("aria-label")));
  39  | /** The value shown for `label` in the `section` of the open details. */
  40  | const value = (scope: Locator, section: string, label: string) =>
  41  |   scope.locator(`section[aria-label="${section}"] dt`, { hasText: new RegExp(`^${label}$`) }).locator("xpath=following-sibling::dd[1]");
  42  | const rows = (scope: Locator, section: string) => scope.locator(`section[aria-label="${section}"] dt`).allTextContents();
  43  | 
  44  | /** The card (Booking requests, Equipment, Browse events) for the event called `name`, with its details opened. */
  45  | async function openCardDetails(page: Page, name: string): Promise<Locator> {
  46  |   const card = page.locator(".card").filter({ has: page.getByText(name, { exact: true }) }).filter({ has: page.getByRole("button", { name: "Details" }) });
  47  |   await card.getByRole("button", { name: "Details" }).click();
  48  |   await expect(card.getByText(/^Last updated /)).toBeVisible();
  49  |   return card;
  50  | }
  51  | 
  52  | async function checkValues(scope: Locator, expected: Array<[string, string, string]>) {
  53  |   for (const [section, label, text] of expected) await expect(value(scope, section, label), `${section} / ${label}`).toHaveText(text);
  54  | }
  55  | 
  56  | test.describe("US15 - View Event Information", () => {
  57  |   test("[TC-051] [US15-AC1] the organiser can view all the information of their own event", async ({ page }, info) => {
  58  |     await signIn(page, MAYA, /\/my-events/);
  59  |     await myEventsRow(page, names.symposium).getByRole("link", { name: "View" }).click();
  60  |     await expect(page).toHaveURL(new RegExp(`/my-events/${s.symposium}$`));
  61  |     const details = page.locator("body");
  62  |     await expect(page.getByRole("heading", { name: names.symposium })).toBeVisible();
  63  |     await expect(page.getByText(/^Last updated \d{2} \w{3} \d{4}, \d{2}:\d{2}$/)).toBeVisible();
  64  |     expect(await sectionTitles(details)).toEqual(ALL_SECTIONS);
  65  |     await checkValues(details, [
  66  |       ["Event", "Status", "Confirmed"], ["Event", "Event type", "Conference"], ["Event", "Time", "09:00 – 17:00"], ["Event", "Expected attendance", "180"],
  67  |       ["People", "Organiser", MAYA.name], ["People", "Coordinator", PRIYA.name],
  68  |       ["Venue", "Venue", s.venue], ["Venue", "Booking", "Approved"], ["Venue", "Preferred location", "Central campus"], ["Venue", "Required capacity", "200"],
  69  |       ["Venue", "Layout", "Theatre"], ["Venue", "Facilities", "Projector, PA system"], ["Venue", "Accessibility", "Wheelchair Access"],
  70  |       ["Equipment", "Requested", "2 × Projector (HDMI to lectern)"], ["Equipment", "Equipment status", "Requested"],
  71  |       ["Registration", "Attendee registration", "Open"], ["Registration", "Capacity limit", "200"],
  72  |       ["Review", "Decision", "Approved: Programme and venue confirmed."],
  73  |     ]);
  74  |     observed(info, `/my-events/${s.symposium} showed the name, Confirmed, "Last updated" and the sections ${ALL_SECTIONS.join(", ")} with the saved values (e.g. 2 × Projector (HDMI to lectern); Decision "Approved: Programme and venue confirmed.").`);
  75  |   });
  76  | 
  77  |   test("[TC-052] [US15-AC1] the coordinator can view the information of an event assigned to them", async ({ page }, info) => {
  78  |     await signIn(page, PRIYA, /\/queue/);
  79  |     await openInQueue(page, names.symposium);
  80  |     await expect(page.getByText(/^Last updated /).first()).toBeVisible();
  81  |     await page.getByRole("button", { name: "Details", exact: true }).click();
  82  |     const details = page.locator("body");
  83  |     await expect(details.locator("section[aria-label]").first()).toBeVisible();
> 84  |     expect(await sectionTitles(details)).toEqual(ALL_SECTIONS);
      |                                          ^ Error: expect(received).toEqual(expected) // deep equality
  85  |     await checkValues(details, [["People", "Coordinator", PRIYA.name], ["Equipment", "Requested", "2 × Projector (HDMI to lectern)"],
  86  |       ["Review", "Decision", "Approved: Programme and venue confirmed."]]);
  87  |     observed(info, `The workspace header showed "Last updated"; Details showed the same six sections and values as the organiser sees.`);
  88  |   });
  89  | 
  90  |   test("[TC-053] [US15-AC1] venue staff can view the event and venue information of an event with a booking request", async ({ page }, info) => {
  91  |     await signIn(page, DANIEL, /\/bookings/);
  92  |     const card = await openCardDetails(page, names.pitch);
  93  |     expect(await sectionTitles(card)).toEqual(["Event", "People", "Venue"]);
  94  |     await checkValues(card, [["Venue", "Booking", "Pending"], ["Venue", "Preferred location", "Central campus"], ["Venue", "Required capacity", "120"],
  95  |       ["Venue", "Layout", "Standing"], ["Venue", "Accessibility", "None"], ["Event", "Expected attendance", "95"]]);
  96  |     observed(info, `Details for ${names.pitch} showed only Event, People and Venue (booking Pending, Central campus, 120, Standing, accessibility None); no Equipment, Registration or Review.`);
  97  |   });
  98  | 
  99  |   test("[TC-054] [US15-AC1] technical support can view the event and equipment information of an event requesting equipment", async ({ page }, info) => {
  100 |     await signIn(page, WEI, /\/equipment/);
  101 |     const card = await openCardDetails(page, names.symposium);
  102 |     expect(await sectionTitles(card)).toEqual(["Event", "People", "Venue", "Equipment"]);
  103 |     expect(await rows(card, "Venue")).toEqual(["Venue"]);
  104 |     await checkValues(card, [["Venue", "Venue", s.venue], ["Equipment", "Requested", "2 × Projector (HDMI to lectern)"]]);
  105 |     observed(info, `Details showed Event, People, the venue name only (${s.venue}) and Equipment (2 × Projector (HDMI to lectern)); no booking state, venue needs, accessibility, Registration or Review.`);
  106 |   });
  107 | 
  108 |   test("[TC-055] [US15-AC1] an attendee can view the public information of a confirmed event open for registration", async ({ page }, info) => {
  109 |     await signIn(page, SAM, /\/browse/);
  110 |     const card = await openCardDetails(page, names.symposium);
  111 |     expect(await sectionTitles(card)).toEqual(["Event", "People", "Venue", "Registration"]);
  112 |     expect(await rows(card, "Event")).not.toContain("Expected attendance");
  113 |     expect(await rows(card, "People")).toEqual(["Organiser"]);
  114 |     expect(await rows(card, "Venue")).toEqual(["Venue", "Accessibility"]);
  115 |     await checkValues(card, [["Registration", "Attendee registration", "Open"], ["Registration", "Capacity limit", "200"]]);
  116 |     observed(info, "Details showed Event (without expected attendance), the organiser only, the venue name and accessibility, and Registration (Open, 200); no coordinator, venue needs, booking, Equipment or Review.");
  117 |   });
  118 | 
  119 |   test("[TC-056] [US15-AC2] fields a role may not see are left out of the event data, not sent as empty", async ({ baseURL }, info) => {
  120 |     const counts: string[] = [];
  121 |     for (const [role, who] of [["organiser", MAYA], ["coordinator", PRIYA], ["venue", DANIEL], ["tech", WEI], ["attendee", SAM]] as const) {
  122 |       const event = await (await (await apiAs(baseURL!, who)).get(`/api/events/${s.symposium}`)).json();
  123 |       expect(Object.keys(event).sort(), role).toEqual([...FIELDS[role]].sort());
  124 |       counts.push(`${role} ${Object.keys(event).length}`);
  125 |     }
  126 |     const attendee = await (await (await apiAs(baseURL!, SAM)).get(`/api/events/${s.symposium}`)).json();
  127 |     expect(Object.entries(attendee).filter(([, v]) => v === null).map(([k]) => k)).toEqual([]);
  128 |     observed(info, `GET /events/{id} returned exactly each role's permitted fields (${counts.join(", ")}); hidden fields were absent rather than null, and the attendee's response had no null fields.`);
  129 |   });
  130 | 
  131 |   test("[TC-057] [US15-AC2] a permitted field with no value yet is shown as not set, not hidden", async ({ page }, info) => {
  132 |     await signIn(page, PRIYA, /\/queue/);
  133 |     await openInQueue(page, names.bare);
  134 |     await page.getByRole("button", { name: "Details", exact: true }).click();
  135 |     const details = page.locator("body");
  136 |     await expect(details.locator("section[aria-label]").first()).toBeVisible();
  137 |     await checkValues(details, [
  138 |       ["Event", "Expected attendance", "Not set"], ["People", "Coordinator", "Not yet assigned"], ["Venue", "Venue", "Not booked yet"],
  139 |       ["Venue", "Booking", "Not requested"], ["Venue", "Preferred location", "Not set"], ["Venue", "Required capacity", "Not set"],
  140 |       ["Venue", "Layout", "Not set"], ["Venue", "Facilities", "None"], ["Venue", "Accessibility", "None"], ["Equipment", "Requested", "None"],
  141 |       ["Equipment", "Equipment status", "None requested"], ["Registration", "Attendee registration", "Not required"],
  142 |     ]);
  143 |     observed(info, `Details for ${names.bare} showed every empty field: attendance Not set, coordinator Not yet assigned, venue Not booked yet, booking Not requested, location/capacity/layout Not set, facilities/accessibility/equipment None, equipment status None requested, registration Not required.`);
  144 |   });
  145 | 
  146 |   test("[TC-058] [US15-AC3] the details show the latest saved values and a later last-updated time after an edit", async ({ page }, info) => {
  147 |     const name = unique("Robotics Club Showcase");
  148 |     await signIn(page, MAYA, /\/my-events/);
  149 |     await page.getByRole("link", { name: "New request" }).click();
  150 |     await page.getByPlaceholder("Alumni Homecoming Dinner").fill(name);
  151 |     await page.locator("select.text-input").selectOption("other");
  152 |     await page.getByPlaceholder("180").fill("70");
  153 |     await page.getByRole("button", { name: "Save as draft" }).click();
  154 |     await expect(toast(page)).toContainText("Draft saved.");
  155 | 
  156 |     const view = async (title: string) => {
  157 |       await myEventsRow(page, title).getByRole("link", { name: "View" }).click();
  158 |       await expect(page.getByRole("heading", { name: title })).toBeVisible();
  159 |       const stamp = await page.locator("time").first().getAttribute("datetime");
  160 |       const pax = await value(page.locator("body"), "Event", "Expected attendance").textContent();
  161 |       await page.getByRole("link", { name: "← My events" }).click();
  162 |       return { stamp: Date.parse(stamp!), pax };
  163 |     };
  164 |     const first = await view(name);
  165 |     expect(first.pax).toBe("70");
  166 | 
  167 |     const renamed = `${name} 2026`;
  168 |     await myEventsRow(page, name).getByRole("button", { name: "Continue" }).click();
  169 |     await page.getByPlaceholder("Alumni Homecoming Dinner").fill(renamed);
  170 |     await page.getByPlaceholder("180").fill("85");
  171 |     // SQLite records whole seconds: save in a later second to test a later timestamp.
  172 |     await expect.poll(() => Date.now()).toBeGreaterThan(first.stamp + 1000);
  173 |     await page.getByRole("button", { name: "Save as draft" }).click();
  174 |     await expect(toast(page)).toContainText("Draft saved.");
  175 |     const second = await view(renamed);
  176 |     expect(second.pax).toBe("85");
  177 |     expect(second.stamp).toBeGreaterThan(first.stamp);
  178 |     observed(info, `The first View showed ${name} with 70 expected; after renaming to "${renamed}" with 85 the View showed the new values and a later last-updated time (${new Date(first.stamp).toISOString()} -> ${new Date(second.stamp).toISOString()}).`);
  179 |   });
  180 | 
  181 |   test("[TC-059] [US15-AC4] every role sees the same values and last-updated time for the same event", async ({ baseURL }, info) => {
  182 |     const get = async (who: typeof MAYA) => (await (await apiAs(baseURL!, who)).get(`/api/events/${s.symposium}`)).json();
  183 |     const organiser = await get(MAYA);
  184 |     for (const who of [PRIYA, DANIEL, WEI, SAM]) {
```